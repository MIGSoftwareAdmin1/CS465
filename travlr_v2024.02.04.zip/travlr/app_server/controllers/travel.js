var fs = require('fs');

// Reading the trips data from the JSON file
var trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf8'));

/* GET travel view */
const travel = (req, res) => {
    // Rendering the 'travel' template and passing both title and trips data to it
    console.log("Travel conroller called."); // log to check the data handshake
    res.render('travel', { title: 'Travlr Getaways', trips: trips }); // Changed line
};

module.exports = {
    travel
};
